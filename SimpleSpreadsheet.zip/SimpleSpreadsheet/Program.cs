﻿
using System;

namespace SimpleSpreadsheet
{
	class Program
	{
		public static void Main(string[] args)
		{
			while(true)
			{
				Console.Write("enter command:");
				var result = Command.GetResult(Console.ReadLine());
				Console.WriteLine(result);
				Command.Clear();
				System.Threading.Thread.Sleep(500);
			}
		}
	}
}