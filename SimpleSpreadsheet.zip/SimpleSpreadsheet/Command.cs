﻿
using System;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// The command class is used for inputing command lines and displaying.
	/// </summary>
	public static class Command
	{
		private static Spreadsheet spreadSheet = null;
		public static string GetResult(string command)
		{
			if (command.Length < 2)
			{
				if (command.ToUpper() == "Q") 
				{
					Environment.Exit(0);
					return string.Empty;
				}
				spreadSheet = new Spreadsheet();
				return spreadSheet.ToString();
			}
			string commandPrefix = command.Substring(0, 1).ToUpper();
			var splitedArray = command.Substring(2).Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
			 
			switch (commandPrefix) 
			{
				case "C":
					spreadSheet = new Spreadsheet(splitedArray);
					break;
				case "S":
					spreadSheet = new Sum(splitedArray);
					break;
				case "N":
					spreadSheet = new Insert(splitedArray);
					break;
			}

			return spreadSheet.ToString();
		}
		public static void Clear()
		{
			if (null != spreadSheet)
			spreadSheet.Clear();
		}
	}
}
