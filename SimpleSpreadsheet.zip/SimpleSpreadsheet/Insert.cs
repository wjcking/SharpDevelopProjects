﻿/*
 * Created by Jacky.wu.
 */
using System;
using System.Collections.Generic;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// Description of Insert.
	/// </summary>
	public class Insert:Spreadsheet
	{
		public Insert(string[] splited) : base(splited)
		{
			string key;
			int x = 0;
			int y = 0;
			int v = 0;
			foreach (var each in splited) 
			{
				if (each.Length < 1)
					continue;
			 
				key = each.Substring(0, 1).ToLower();
			 
				if (key == "x")
					int.TryParse(each.Substring(1), out x);
				else if (key == "y")
					int.TryParse(each.Substring(1), out y);
				else if (key == "v")
					int.TryParse(each.Substring(1), out v); 
			}	
		
		 
			vectors[x, y] = v;
			stringBuilder.Append(v.ToString().PadRight(3));
		}
		
	}
}
