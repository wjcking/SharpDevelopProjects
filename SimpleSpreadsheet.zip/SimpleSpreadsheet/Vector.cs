﻿/*
 * Created by Jacky.
 */
using System;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// Vector info for store coordinates
	/// </summary>
	public class Vector
	{
		private int[][] 
		public Vector()
		{
			
		}
		public Vector(string coordinateCommand)
		{
			if (coordinateCommand.Length < 2)
				return;
			
			var name  = coordinateCommand.Substring(0,1).ToLower();
			if (name == "x")
				int.TryParse(name, out x);
			else if (name == "y")
				int.TryParse(name, out y);
			else if (name == "v")
				int.TryParse(name, out v);				
		}
		public override string ToString()
		{
			return "|".PadRight(3) + v.ToString().PadRight(3);
		}

	}
	
}
