﻿
using System;
using System.Collections.Generic;
using System.Text;
namespace SimpleSpreadsheet
{
	/// <summary>
	/// Basic settings of Spreadsheet.
	/// </summary>
	public class Spreadsheet
	{
		protected const char DELIMITER_CONNECT = '-';
		protected const char DELIMITER_SLICE = '|';
 
		private int width = 20;
		private int height = 4;
		
		protected static StringBuilder stringBuilder = null;
		protected static int[,] vectors;
		public Spreadsheet(string[] splited)
		{
				int.TryParse(splited[0], out width);
				int.TryParse(splited[1], out height);
				vectors = new int[width, height];
		
			if (null == stringBuilder)
				stringBuilder = new StringBuilder();
			
			stringBuilder.AppendLine(string.Empty.PadRight(width * 3, DELIMITER_CONNECT));
		}
		public Spreadsheet()
		{
			if (null == stringBuilder)
				stringBuilder = new StringBuilder();
			
			stringBuilder.AppendLine(string.Empty.PadRight(width * 3, DELIMITER_CONNECT));
			for (int i = 0; i < height; i++) 
			{
				stringBuilder.Append(DELIMITER_SLICE.ToString().PadRight(width));
				stringBuilder.AppendLine(DELIMITER_SLICE.ToString());
			}
		}
		public override string ToString()
		{	
			stringBuilder.AppendLine(string.Empty.PadRight(width*3, DELIMITER_CONNECT));
			return stringBuilder.ToString();
		}
		
		public void Clear()
		{
			stringBuilder.Clear();
		}
	}
}
