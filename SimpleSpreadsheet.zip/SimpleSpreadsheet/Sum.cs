﻿/*
 * Created by Jacky.
 */
using System;

namespace SimpleSpreadsheet
{
	/// <summary>
	/// Description of Sum.
	/// </summary>
	public class Sum : Spreadsheet
	{
		public Sum(string[] splited): base(splited)
		{
			foreach(var each in splited)
			{
			 
			}
		}
	}
}
